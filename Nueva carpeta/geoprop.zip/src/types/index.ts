export interface Publisher {
  type: 'inmobiliaria' | 'particular';
  name: string;
  phone: string | null;
}

export interface Province {
  id: string;
  name: string;
  slug: string;
}

export interface City {
  id: string;
  name: string;
  slug: string;
  latitude: string | number | null;
  longitude: string | number | null;
}

export type ListingType = 'normal' | 'featured';
export type ListingDuration = 15 | 30 | 60;
export type ListingStatus = 'draft' | 'active' | 'expired';

export interface PropertyListing {
  listingType: ListingType;
  listingDuration: ListingDuration;
  listingExpiresAt: string;
  isFeatured: boolean;
  featuredUntil: string | null;
  status: ListingStatus;
  isActive: boolean;
}

export interface Property {
  id: string | number;
  title: string;
  subtitle?: string | null;
  operation?: 'venta' | 'alquiler' | null;
  type?: 'casa' | 'departamento' | 'lote' | 'comercial' | 'galpon-deposito' |null;
  price?: {
    amount?: number | null;
    currency?: string | null;
    raw?: string | null;
  };
  description?: string | null;
  descriptionShort?: string | null;
  location?: {
    city?: string | null;
    province?: string | null;
    locality?: string | null;
  };
  sourceUrl?: string | null;
  specs?: {
    totalArea?: number | null;
    coveredArea?: number | null;
    landArea?: number | null;
    rooms?: number | null;
    bedrooms?: number | null;
    bathrooms?: number | null;
    parking?: number | null;
    ageYears?: number | null;
    expensesMonthly?: number | null;
  };
  image?: string | null;
  images?: string[];
  publisher?: Publisher;
  listing?: PropertyListing;
  condition?: 'a_estrenar' | 'usado' | 'a_refaccionar' | null;
  createdAt?: string | null;
  publishedAt?: string | null;
  views?: number | null;
}

export interface PropertyComparison {
  id: string | number;
  title: string;
  city?: string | null;
  province?: string | null;
  price: number;
  currency: string;
  area?: number | null;
  pricePerSqm?: number | null;
  bedrooms?: number | null;
  bathrooms?: number | null;
  garages?: number | null;
  operation: 'sale' | 'rent';
  propertyType: string;
  views?: number | null;
  inquiriesCount?: number;
}

export interface PropertyFilters {
  city?: string;
  province?: string;
 operation?: 'venta' | 'alquiler' | null;
 type?: 'casa' | 'departamento' | 'lote' | 'comercial' | 'galpon-deposito' | null;
  sizeCategory?: 'small' | 'medium' | 'large';
  minArea?: number;
  maxArea?: number;
  minBedrooms?: number;
  maxBedrooms?: number;
  minBathrooms?: number;
  maxBathrooms?: number;
  minParking?: number;
  maxParking?: number;
  minPrice?: number;
  maxPrice?: number;
  currency?: string;
  locality?: string;
  search?: string;
  sortBy?: string;
  order?: 'asc' | 'desc';
  publisherType?: string;
  external?: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  name: string;
  email: string;
  password: string;
  role?: 'admin' | 'agent' | 'viewer';
  phone?: string;
  clientName?: string;
  clientEmail?: string;
  clientPhone?: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export type UserPlan = 'FREE' | 'INMOBILIARIA' | 'BROKER';
export type UserPlanSource = 'user' | 'client' | 'default';

export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string | null;
  clientId?: string;
  roleId?: string;
  role?: string;
  active?: boolean;
  plan?: UserPlan;
  planSource?: UserPlanSource | null;
  planOverride?: UserPlan | null;
  planExpiresAt?: string | null;
  subscriptionStatus?: string | null;
  client?: {
    id: string;
    name: string;
  };
}

export interface UserRole {
  id: string;
  name: string;
}

export interface UserClient {
  id: string;
  name: string;
}

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  roleId: string;
  clientId: string;
  active: boolean;
  created_by?: string;
  role?: UserRole | string;
  client?: UserClient;
  plan?: UserPlan;
  planSource?: UserPlanSource | null;
  planOverride?: UserPlan | null;
  planExpiresAt?: string | null;
  subscriptionStatus?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export interface CreateUserPayload {
  name: string;
  email: string;
  password: string;
  roleId: string;
  active?: boolean;
  plan?: UserPlan | null;
  planExpiresAt?: string | null;
  subscriptionStatus?: string | null;
}

export interface UpdateUserPayload {
  name?: string;
  email?: string;
  roleId?: string;
  active?: boolean;
  password?: string;
  phone?: string | null;
  plan?: UserPlan | null;
  planExpiresAt?: string | null;
  subscriptionStatus?: string | null;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  error: string | null;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  pages: number;
}

export interface PaginatedResponse<T> {
  success: boolean;
  data: T;
  pagination: PaginationMeta;
  error: string | null;
}

export interface DashboardSummary {
  activeProperties: number;
  inquiriesThisWeek: number;
  expiringSoon: number;
}

export interface PropertyPerformanceMetric {
  id: string;
  title: string;
  location: string | null;
  views: number;
  viewsCurrent: number;
  viewsPrevious: number;
  inquiriesTotal: number;
  conversion: number;
  inquiriesCurrent: number;
  inquiriesPrevious: number;
  changePercent: number;
  price: number;
  currency: string;
  totalArea: number | null;
  coveredArea: number | null;
}

export interface ZonePriceStat {
  cityId: string;
  cityName: string;
  avgPricePerM2: number | null;
  minPricePerM2: number | null;
  maxPricePerM2: number | null;
  currency: string | null;
  userProperties: UserProperty[] | null;
}

export interface UserProperty {
  id: string;
  title: string;
  pricePerSqm: number;
}

export interface InquiryPropertySummary {
  id: string;
  title: string;
  createdBy: string;
  clientId: string;
}

export interface PropertyInquiry {
  id: string;
  propertyId: string;
  clientId: string;
  userId: string | null;
  name: string | null;
  email: string;
  phone: string | null;
  message: string;
  source: string | null;
  createdAt: string;
  updatedAt: string;
  property?: InquiryPropertySummary;
}

export interface CreateInquiryPayload {
  propertyId?: string;
  name?: string;
  email?: string;
  phone?: string;
  message: string;
  source?: string;
}

export interface InquiryListParams {
  page?: number;
  limit?: number;
  from?: string;
  to?: string;
}

export interface NotificationMetadata {
  inquiryId?: string;
  propertyId?: string;
  propertyTitle?: string;
}

export interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string;
  metadata?: NotificationMetadata | null;
  isRead: boolean;
  createdAt: string;
}

export interface ExpiringProperty {
  propertyId: string;
  title: string;
  listingType: ListingType;
  expiresAt: string;
  daysLeft: number;
  canRenew: boolean;
}

export interface MyPropertiesExtendedData {
  properties: unknown[];
  expiringSoon: ExpiringProperty[];
}

export interface RenewListingPayload {
  listingType: ListingType;
  listingDuration: ListingDuration;
}

export interface CreatePaymentPreferencePayload {
  propertyId: string;
  type: ListingType;
  duration: ListingDuration;
}

export interface PaymentPreference {
  paymentId: string;
  propertyId: string;
  preferenceId: string;
  initPoint: string;
  sandboxInitPoint: string;
  type: ListingType;
  duration: ListingDuration;
  amount: number;
  status: string;
}
